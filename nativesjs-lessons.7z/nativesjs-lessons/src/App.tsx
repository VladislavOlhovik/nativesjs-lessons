import React from 'react';
import './lessons/lesson1/lesson1';
import Lesson3 from './lessons/lesson3/lesson3';

function App() {
  return (
    <div>
      <h1>Please, open the developer tools' console!</h1>
      {/*<Lesson3 />*/}
    </div>
  );
}

export default App;
